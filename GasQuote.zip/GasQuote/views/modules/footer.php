<footer class = "main-footer">
	
	<span><strong>All rights are reseverd.</strong> </span>
</footer>