<header class = "main-header">

	<a href="" class="logo">

		<!-- Logo Mini-->
		<span class = "logo-mini">
			<img src="views/img/template/miniLogo.png" class="img-responsive" style = "padding:10px">

		</span>

		<!-- Logo
		<span class = "logo-lg">
			<img src="views/img/template/oil-linear.png" class="img-responsive" style = "padding:10px 0px">

		</span>
	-->


	</a>

	<!--=============================================
	=            Navigation Bar            =
	=============================================-->
	<nav class ="navbar navbar-static-top" role="navigation">
		<!--Navigation Botton-->
		<a href="#" class="sidebar-toggle" data-toggle="push-menu" role = "button" >
			<span class="sr-only">Toggle Navigation</span>

		</a>

		<!--User Profile-->
		<div class = "navbar-custom-menu">
			<ul class="nav navbar-nav">
				<li class="dropdown user user-menu">
					<a href="#" class ="dropdown-toggle" data-toggle="dropdown" >
						
						<img src= "views/img/template/skeleton.png" class="user-image">
						<span class="hidden-xs"> <?php echo '<tr> <td>'.$_SESSION["username"].'</td></tr>' ?></span>
					</a>
					<!--Dropdown-->

					<ul class="dropdown-menu">
						<li class="user-body">
							<div class="pull-right">
								<a href="logout" class="btn btn-default btn-flat">Log out</a>

							</div>
						</li>
					</ul>
				</li>
			</ul>
		</div>

		
	</nav>
	
	
</header>