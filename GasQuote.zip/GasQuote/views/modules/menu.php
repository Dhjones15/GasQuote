<aside class="main-sidebar">
	<section class="sidebar">
		<ul class="sidebar-menu">
			<li class="active">
				<a href="home">
			
					<i class="fa fa-home"></i>
					<span>Home</span>

				</a>
			</li>

			<li class="active">
				<a href="profile">
			
					<i class="fa fa-user"></i>
					<span>Profile Management</span>

				</a>
			</li>
			<?php
			if($_SESSION["has_info"]=="ok"){
			 echo '<tr>
			<li class="active">
				<a href="quote">
			
					<i class="fa fa-money"></i>
					<span>Quote</span>

				</a>
			</li>
		
			<li class="active">
				<a href="history">
			
					<i class="fa fa-history"></i>
					<span>History</span>

				</a>
			</li>
			</tr>';
			}
			?>
		</ul>
		

	</section>
	

</aside>