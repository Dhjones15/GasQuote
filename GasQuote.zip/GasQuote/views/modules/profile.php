  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Profile Management       
      </h1>
      <ol class="breadcrumb">
        <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>       
        <li class="active">Profile Management</li>
      </ol>
    </section>
    <section class="content">
      <div class="box">
	  <?php
	  if($_SESSION["has_info"]=="no"){
		  echo'
        <div class="box-header with-border">
          <button class="btn btn-primary" data-toggle="modal" data-target="#modalAddUsers">Add Information</button>
        </div>';
	  }
		?>
          <!-- For adding the user -->
        <div class="box-body">
          <table class="table table-bordered table-striped">

          <thead>
             <tr>
              
              <th>Name</th>
              <th>Address</th>
              <th>Address2</th>
              <th>City</th>
              <th>State</th>
              <th>Zip Code</th>
              <th>Actions</th>
            </tr>
          </thead>

            <tbody>


              <?php

              $user = ControllerUser::ctrShowUser();
			  if($user !=False){
	            echo '<tr>
               
                <td>'.$user["client_name"].'</td>
				<td>'.$user["address1"].'</td>
                <td>'.$user["address2"].'</td>
                <td>'.$user["city"].'</td>
                <td>'.$user["state"].'</td>
                <td>'.$user["zip"].'</td>
         
                 <td>
                    <div class="btn-group">
                        <button class="btn btn-warning btnEditUser" idUser="'.$_SESSION["username"].'" data-toggle="modal" data-target="#modalEditUser"><i class="fa fa-pencil"></i></button>
                  
                    </div>
                  </td>
              </tr>';
			  }

              

              ?>
              
         

            </tbody>
          </table>
        </div>
      </div>
    </section>
  </div>

  <!--Add Info-->
<!-- Modal -->
<div id="modalAddUsers" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">

      <!--Burasi Silinebilir-->

      <form role="form" method="post">
        <div class="modal-header" style="background:#3c8dbc; color:white">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Profile Information</h4>
        </div>

        <div class="modal-body">
          <div class="box-body">


          
        <!--Employee Name-->

      <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
            <input type="text" class="form-control input-lg" name="newName" placeholder="Insert Name" required>
          </div>
      </div>


  <!-- Address Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="newAddress" placeholder="Insert Address 1" required>
            </div>
         </div> 
   <!-- Address Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="newAddress2" placeholder="Insert Address 2" optional>
            </div>
         </div>  

    <!-- City Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
             <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="newCity" placeholder="Insert City" required>
            </div>
         </div>  


    <!-- State Entry-->
		 <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
			  <select class="form-control input-lg" name="newState" required>
			  <option value= "">Select State </option>
			  <option value="AL">Alabama</option>	
			  <option value="AK">Alaska</option>
			  <option value="AZ">Arizona</option>
			  <option value="AR">Arkansas</option>
			  <option value="CA">California</option>
			  <option value="CO">Colorado</option>
			  <option value="CT">Connecticut</option>
			  <option value="DE">Delaware</option>
			  <option value="DC">District Of Columbia</option>
			  <option value="FL">Florida</option>
			  <option value="GA">Georgia</option>
			  <option value="HI">Hawaii</option>
			  <option value="ID">Idaho</option>
			  <option value="IL">Illinois</option>
			  <option value="IN">Indiana</option>
			  <option value="IA">Iowa</option>
			  <option value="KS">Kansas</option>
			  <option value="KY">Kentucky</option>
			  <option value="LA">Louisiana</option>
			  <option value="ME">Maine</option>
			  <option value="MD">Maryland</option>
			  <option value="MA">Massachusetts</option>
			  <option value="MI">Michigan</option>
			  <option value="MN">Minnesota</option>
			  <option value="MS">Mississippi</option>
			  <option value="MO">Missouri</option>
			  <option value="MT">Montana</option>
			  <option value="NE">Nebraska</option>
			  <option value="NV">Nevada</option>
			  <option value="NH">New Hampshire</option>
			  <option value="NJ">New Jersey</option>
			  <option value="NM">New Mexico</option>
			  <option value="NY">New York</option>
			  <option value="NC">North Carolina</option>
			  <option value="ND">North Dakota</option>
			  <option value="OH">Ohio</option>
			  <option value="OK">Oklahoma</option>
			  <option value="OR">Oregon</option>
			  <option value="PA">Pennsylvania</option>
			  <option value="RI">Rhode Island</option>
			  <option value="SC">South Carolina</option>
			  <option value="SD">South Dakota</option>
			  <option value="TN">Tennessee</option>
			  <option value="TX">Texas</option>
			  <option value="UT">Utah</option>
			  <option value="VT">Vermont</option>
			  <option value="VA">Virginia</option>
			  <option value="WA">Washington</option>
			  <option value="WV">West Virginia</option>
			  <option value="WI">Wisconsin</option>
			  <option value="WY">Wyoming</option>			  
			  </select>
			 </div>
         </div>

    <!-- Zip Code Entry-->
		<div class="form-group"> 
           <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="newZipCode" placeholder="Insert Zip Code" required>
            </div>
         </div>  



        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>

        <?php
          $createUser = new ControllerUser();
          $createUser -> ctrCreateUser();


        ?>

      </form>
    </div>

  </div>
</div>

<!-- Edit Info-->
<div id="modalEditUser" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">

      <!--Burasi Silinebilir-->

      <form role="form" method="post">
        <div class="modal-header" style="background:#3c8dbc; color:white">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Edit Profile Information</h4>
        </div>

        <div class="modal-body">
          <div class="box-body">



        <!--Employee Name-->

      <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
            <input type="text" class="form-control input-lg" name="editName" placeholder="Insert Name" required>
          </div>
      </div>


  <!-- Address Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="editAddress" placeholder="Insert Address 1" required>
            </div>
         </div> 
   <!-- Address Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="editAddress2" placeholder="Insert Address 2" optional>
            </div>
         </div>  

    <!-- City Entry-->
          <div class="form-group"> 
            <div class="input-group"> 
             <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="editCity" placeholder="Insert City" required>
            </div>
         </div>  

    <!-- State Entry-->

      <div class="form-group"> 
            <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
			  <select class="form-control input-lg" name="editState" required>
			  <option value= "">Select State </option>
			  <option value="AL">Alabama</option>	
			  <option value="AK">Alaska</option>
			  <option value="AZ">Arizona</option>
			  <option value="AR">Arkansas</option>
			  <option value="CA">California</option>
			  <option value="CO">Colorado</option>
			  <option value="CT">Connecticut</option>
			  <option value="DE">Delaware</option>
			  <option value="DC">District Of Columbia</option>
			  <option value="FL">Florida</option>
			  <option value="GA">Georgia</option>
			  <option value="HI">Hawaii</option>
			  <option value="ID">Idaho</option>
			  <option value="IL">Illinois</option>
			  <option value="IN">Indiana</option>
			  <option value="IA">Iowa</option>
			  <option value="KS">Kansas</option>
			  <option value="KY">Kentucky</option>
			  <option value="LA">Louisiana</option>
			  <option value="ME">Maine</option>
			  <option value="MD">Maryland</option>
			  <option value="MA">Massachusetts</option>
			  <option value="MI">Michigan</option>
			  <option value="MN">Minnesota</option>
			  <option value="MS">Mississippi</option>
			  <option value="MO">Missouri</option>
			  <option value="MT">Montana</option>
			  <option value="NE">Nebraska</option>
			  <option value="NV">Nevada</option>
			  <option value="NH">New Hampshire</option>
			  <option value="NJ">New Jersey</option>
			  <option value="NM">New Mexico</option>
			  <option value="NY">New York</option>
			  <option value="NC">North Carolina</option>
			  <option value="ND">North Dakota</option>
			  <option value="OH">Ohio</option>
			  <option value="OK">Oklahoma</option>
			  <option value="OR">Oregon</option>
			  <option value="PA">Pennsylvania</option>
			  <option value="RI">Rhode Island</option>
			  <option value="SC">South Carolina</option>
			  <option value="SD">South Dakota</option>
			  <option value="TN">Tennessee</option>
			  <option value="TX">Texas</option>
			  <option value="UT">Utah</option>
			  <option value="VT">Vermont</option>
			  <option value="VA">Virginia</option>
			  <option value="WA">Washington</option>
			  <option value="WV">West Virginia</option>
			  <option value="WI">Wisconsin</option>
			  <option value="WY">Wyoming</option>			  
			  </select>
			 </div>
         </div>

    <!-- Zip Code Entry-->
     <div class="form-group"> 
           <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
              <input type="text" class="form-control input-lg" name="editZipCode" placeholder="Insert Zip Code" required>
            </div>
         </div>  



        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>

        <?php
          $createUser = new ControllerUser();
          $createUser -> ctrEditUser();


        ?>

      </form>
    </div>

  </div>
</div>