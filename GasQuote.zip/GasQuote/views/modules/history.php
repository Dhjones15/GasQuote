 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Quote History
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
       
        <li class="active">Quote History</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

         <!-- Default box -->
      <div class="box">

        <div class="box-body">
          <table class="table table-bordered table-striped tablas">

          <thead>
             <tr>
            
                <th>Gallon Requested</th>
                <th>Delivery Address</th> 
                <th>Delivery Date</th>
                <th>Suggested Price</th>
                <th>Total Amount Due</th>
               
            </tr>
          </thead>


                      <tbody>


              <?php

        $item = null;
        $value = null;
			  
        $user = ControllerHistory::ctrShowHistory($item, $value);
			//  $address=ControllerUser::ctrShowUser();
			  
              if ($user == False) {
				 echo'<br><div class="alert alert-danger"> No history found. </div></br>';
			  }
			  
			  else {	  
				foreach ($user as $key => $value){
					echo '<tr>
					
					<td>'.$value["gallons_requested"].'</td>
					<td>'.$value["address"].'</td>
					<td>'.$value["delivery_date"].'</td>
					<td>'.$value["suggested_price"].'</td>
					<td>'.$value["amount_due"].'</td>
					</tr>';
				}
				
			  }
              ?>
              
         

            </tbody>

          
          </table>


            
        </div>
        <!-- /.box-body -->
       
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->