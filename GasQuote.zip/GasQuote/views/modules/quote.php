 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Gas Quote
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
       
        <li class="active">Gas Quote</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

          <button class="btn btn-primary" data-toggle ="modal" data-target="#modalgetQuote">Get Quote</button>
          

          
        </div>
        <div class="box-body">
        <table class="table table-bordered table-striped">

          <thead>
             <tr>
                <th>Delivery Address</th>
                <th>Gallon Requested</th>
                <th>Delivery Date</th>            
                <th>Suggested Price</th>
                <th>Total Amount Due</th>
               
              </tr>
          </thead>
            
             <tbody>


              <?php

               $item = null;
               $value = null;

             

              $user = ControllerQuote::ctrShowQuote($item, $value);
             
              if($user!=False){
              foreach ($user as $key => $value){
            


                echo '<tr>
                <td>'.$value["state"].'</td>
                <td>'.$value["gallons_requested"].'</td>
                <td>'.$value["delivery_date"].'</td>
                <td>'.$value["suggested_price"].'</td>
                <td>'.$value["amount_due"].'</td>
                
                      </tr>';
          
			  }
			  }
                       

              ?>
              
         

            </tbody>
          
          </table>
          
        </div>
        <!-- /.box-body -->
       
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Modal -->
<div id="modalgetQuote" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">

      <!--Burasi Silinebilir-->

      <form role="form" method="post">
        <div class="modal-header" style="background:#3c8dbc; color:white">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enter Informantion</h4>
        </div>

        <div class="modal-body">
          <div class="box-body">


       <!--User Name-->

      
          

        <!--Galons-->

      <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-tint"></i></span>
            <input type="text" class="form-control input-lg" name="newGallonRequested" placeholder="Insert Requested Gallons" required>
          </div>
      </div>




   <!-- Address Entry-->
         <!-- DOH Entry-->
       <div class="form-group"> 
          <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
              <input type="date" class="form-control input-lg" name="newDeliveryDate" placeholder="Insert Delivery Date" required>
            </div>
         </div>  
    

        </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Submit Request</button>
        </div>

 
        <?php
          $createQuote = new ControllerQuote();
          $createQuote -> ctrCreateQuote();


        ?>

      </form>
    </div>

  </div>
</div>