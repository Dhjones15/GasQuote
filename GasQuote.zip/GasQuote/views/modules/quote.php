 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Gas Quote
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
       
        <li class="active">Gas Quote</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

        <!--   <button class="btn btn-primary" data-toggle ="modal"  data-target="#modalgetQuote">Get Quote</button> -->
        
          
    <form method="post" id="gasQuote">

     

        <!--Galons-->

      <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-tint"></i></span>
            <input type="text" class="form-control input-lg" name="newGallonRequested" value = "<?php  if(isset($_POST['newGallonRequested'])){echo $_POST['newGallonRequested'];} ?>" placeholder="Insert Requested Gallons" required>
          </div>
      </div>


     <div class="form-group"> 
          <div class="input-group"> 
              <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
              <input type="date" min="<?php echo date ("Y-m-d"); ?>" class="form-control input-lg" name="newDeliveryDate" value = "<?php  if(isset($_POST['newDeliveryDate'])){echo $_POST['newDeliveryDate'];} ?>" placeholder="Insert Delivery Date" required>
            </div>
         </div>
		  <?php
               $item = null;
               $value = null;

              $user = ControllerUser::ctrShowUser($item, $value);
			  $_POST['newAddress']=$user['address1'].' '.$user['address2'];
			  ?>
	 <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-map-pin"></i></span>
            <input type="text" class="form-control input-lg" name="newAddress" value = "<?php  if(isset($_POST['newAddress'])){echo $_POST['newAddress'];} ?>" placeholder="Shipping Address" required readonly>
          </div>
      </div>

		 
	 <?php
	  if(isset($_POST["Get"])){
			
			$getQuote = new ControllerQuote();
			$_POST['newSuggestedPrice']= $getQuote -> ctrGetPricing();
			$_POST['newTotalAmount']=$_POST['newSuggestedPrice']*$_POST['newGallonRequested'];
	  }
	  ?>
	
	 <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-ticket"></i></span>
            <input type="text" class="form-control input-lg" name="newSuggestedPrice" value = "<?php  if(isset($_POST['newSuggestedPrice'])){echo $_POST['newSuggestedPrice'];} ?>" placeholder="Suggested Price" required readonly>
          </div>
      </div>
	  
	   <div class="form-group"> 
          <div class="input-group"> 
            <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
            <input type="text" class="form-control input-lg" name="newTotalAmount" value = "<?php  if(isset($_POST['newTotalAmount'])){echo $_POST['newTotalAmount'];} ?>" placeholder="Total Amount" required readonly>
          </div>
      </div>
      <div class="row">
        
    <!-- /.col -->
        

       <div class="col-xs-4">
          <button type="submit" name="Get" value="Get" class="btn btn-primary">Get Quote</button>
		   <button type="submit" name="Submit" value="Submit" class="btn btn-primary">Submit Request</button>

        </div>
             
  
        <!-- /.col -->
      </div>



      <?php
   
    
        if(isset($_POST["Submit"])&&$_POST['newSuggestedPrice']!=0){

          $createQuote = new ControllerQuote();
          $createQuote -> ctrCreateQuote();
        }elseif(isset($_POST["Submit"])&&$_POST['newSuggestedPrice']==0){
			echo  '<script>
		swal({
				type: "error",
				title: "Get your Quote first! ",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';
		}

        ?>

      </div>
      <!-- /.box -->

	</div>
	</div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<!-- Modal -->
<!-- <div id="modalgetQuote" data-backdrop="static" role="dialog">
  <div class="modal-dialog">



    </div>

  </div>
</div>
