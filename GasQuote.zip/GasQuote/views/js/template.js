 /*=============================================
 =           SideBar Menu           =
 =============================================*/
 
 
 
 $('.sidebar-menu').tree()

 $(".tablas").DataTable();

$(function () {
  $('[data-toggle="popover"]').popover();
});



  
  $("#estimate").click(function(){
    $("p").append(" <b>Appended text</b>.");
  });


 $('#modalgetQuote').modal('hide'); 
//hide the modal

$('body').removeClass('modal-open'); 
//modal-open class is added on body so it has to be removed

$('.modal-backdrop').remove();
//need to remove div with modal-backdrop class

$("#gasQuote").submit(function(event){
   loadAjax();
   event.preventDefault()
})