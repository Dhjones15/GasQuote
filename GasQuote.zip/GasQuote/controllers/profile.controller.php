<?php


class ControllerUser{
	static public function ctrLogin(){

	
		if(isset($_POST["ingUser"])&&isset($_POST["ingPassword"])){
			if(preg_match("/^[a-zA-Z0-9]{1,20}$/", $_POST["ingUser"]) &&
			   preg_match("/^[a-zA-Z0-9]{1,20}$/", $_POST["ingPassword"])){
			   	$table = "login";
			   	$item = "username";
			   	$value = $_POST["ingUser"];
			   	$response = ModelUser::mdlLogin($table, $item, $value);
				//Added line to check if response came back with tuple or Bool False (if empty)
				if($response!= False){
					if($response["username"]== $_POST["ingUser"] && $response["password"]==$_POST["ingPassword"]){
					
			   		$_SESSION["beginSession"]="ok";
			   		$_SESSION["username"] = $response["username"];
					//Add Check to see if Username has client info already.
					$response=null;
					$response = ModelUser::mdlHasInfo($_SESSION["username"]);
					if ($response==False)
					{
						$_SESSION["has_info"]="no";
					}else{
						$_SESSION["has_info"]="ok";	
					}					
					echo'<script>window.location="home"</script>';
					}else{
						echo'<br><div class="alert alert-danger"> Username or Password is wrong, try again.</div></br>';
					}			   		
				}
				else{
					echo'<br><div class="alert alert-danger"> Username or Password is wrong, try again.</div></br>';
				}

			}else{
				
				echo'<br><div class="alert alert-danger">Incorrect Format! 20 character limit!</div></br>';

			}
		}
	}
	static public function ctrRegister(){	
	if(isset($_POST["ingUser"])&&isset($_POST["ingPassword"])){

			if(preg_match('/^[a-zA-Z0-9]{1,20}$/', $_POST["ingUser"]) &&
			   preg_match('/^[a-zA-Z0-9]{1,20}$/', $_POST["ingPassword"])){
			   	$table = "login";
			   	$item = "username";
			   	$value = $_POST["ingUser"];
			   	$response = ModelUser::mdlLogin($table, $item, $value);
				
				if($response!= False){
		
					echo'<br><div class="alert alert-danger"> Username is taken, try again.</div></br>';
	
				}
				else{
					 $response = ModelUser::mdlRegister($_POST["ingUser"],$_POST["ingPassword"]);
					 if ($response == "ok"){
						 
						echo'<br><div class="alert alert-success"> Account Created! Please log in. </div></br>';
					 }
					 else if($response == "error"){
						 
						echo'<br><div class="alert alert-danger"> Username is taken, try again.</div></br>';
					 }
				}


				}
				
		
		}
	}

static public function ctrCreateUser(){
	
 	if(isset($_POST["newName"])){
	 		if(preg_match('/^[a-zA-Z\s]{1,50}$/', $_POST["newName"])&&
			preg_match('/^[a-zA-Z0-9\s]{1,100}$/', $_POST["newAddress"])&&
			preg_match('/^[a-zA-Z0-9\s]{0,100}|$/', $_POST["newAddress2"])&&
			preg_match('/^[a-zA-Z]{1,100}$/', $_POST["newCity"])&&
			preg_match('/^[A-Z]{2}$/', $_POST["newState"])&&
			preg_match('/^[0-9]{5,9}$/', $_POST["newZipCode"])){
 			$table= "client_info";
 			$data = array(
 						"username" => $_SESSION["username"],
 						"client_name" => $_POST["newName"],
						 "address1" => $_POST["newAddress"],
						"address2" => $_POST["newAddress2"], 
					    "city" => $_POST["newCity"],
						"state" => $_POST["newState"],
						"zip" => $_POST["newZipCode"],
						);
 			$response = ModelUser::mdlCreateUser($table, $data);
 			if($response == "ok"){
				$_SESSION["has_info"]="ok";
 		echo  '<script>
		swal({
				type: "success",
				title: "Information is saved succesfully!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="profile";
					}

					});


		</script>';


 			}




 		}else{

 			echo  '<script>
		
		swal({

				type: "error",
				title: "Information cannot be blank or contain special characters!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="profile";
					}

					});


		</script>';
}



 	}

 }
	static public function ctrShowUser(){
		$user = $_SESSION["username"];	 

	 	$request = ModelUser::modShowUsers($user);
	 	return $request;
 }


 /* Edit Profile */
 
 static public function ctrEditUser(){
	
			
 	if(isset($_POST["editName"])){
 			 if(preg_match('/^[a-zA-Z\s]{1,50}$/', $_POST["editName"])&&
			preg_match('/^[a-zA-Z0-9\s]{1,100}$/', $_POST["editAddress"])&&
			preg_match('/^[a-zA-Z0-9\s]{0,100}|$/', $_POST["editAddress2"])&&
			preg_match('/^[a-zA-Z]{1,100}$/', $_POST["editCity"])&&
			preg_match('/^[A-Z]{2}$/', $_POST["editState"])&&
			preg_match('/^[0-9]{5,9}$/', $_POST["editZipCode"])){

 			$table= "client_info";
 			$data = array(  "username" => $_SESSION["username"],
 				           "client_name" => $_POST["editName"],
						  "address1" => $_POST["editAddress"],
						  "address2" => $_POST["editAddress2"], 
					      "city" => $_POST["editCity"],
						  "state" => $_POST["editState"],
						  "zip" => $_POST["editZipCode"]);
 			$response = ModelUser::mdlEditUser($table, $data);
 			if($response == "ok"){

 		echo  '<script>
		
		swal({

				type: "success",
				title: "Information is saved succesfully!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="profile";
					}

					});


		</script>';
 			}
 		}else{
 			echo  '<script>
		swal({

				type: "error",
				title: "'.$_POST["editZipCode"].'Information cannot be blank or contain special characters!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false
				}).then((result)=>{
					if(result.value){
						window.location="profile";
					}
					});
		</script>';
 		}
   	}
 }

}









