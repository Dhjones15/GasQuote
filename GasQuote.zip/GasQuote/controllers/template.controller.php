<?php

class ControllerTemplate{

	static public function ctrTemplate(){

		include "views/templete.php"; //triggered method
	}



}