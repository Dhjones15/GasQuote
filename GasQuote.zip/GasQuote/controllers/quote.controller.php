<?php

class ControllerQuote{

	static public function ctrShowQuote($item, $value){
		$table = 'fuel_quote';
		$table1 = 'client_info';
		$user = $_SESSION["username"];
		$request = ModelQuote::modShowQuote($table, $table1, $user, $item, $value);

		return $request;
		
		return False;
	}


static public function ctrCreateQuote(){
	
 	if(isset($_POST["newGallonRequested"])&&isset($_POST['newDeliveryDate'])&&isset($_POST['newSuggestedPrice'])&&isset($_POST['newTotalAmount'])){
 		if(preg_match('/^[0-9]{1,9}$/', $_POST["newGallonRequested"])){
 			$user = $_SESSION["username"];
 			$data = array(
 						 "username" => $_SESSION["username"],	
 						"gallons_requested" => $_POST["newGallonRequested"],
						"address" =>$_POST['newAddress'],
						 "delivery_date" => $_POST["newDeliveryDate"],
						 "suggested_price" => $_POST["newSuggestedPrice"],
						"total_due" => $_POST["newTotalAmount"]
						);
 			$response = ModelQuote::mdlCreateQuote($user,$data);
 			if($response == "ok"){
 		echo  '<script>
		swal({
				type: "success",
				title: "Information is saved succesfully! ",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';

 			}else{
 		echo  '<script>
		swal({
				type: "error",
				title: "Error! Something Went Wrong",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';


 			}




 		}else{

 			echo  '<script>
		
		swal({

				type: "error",
				title: "Information cannot be blank or contain special characters!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';
		}



 	}

 }
static public function ctrGetPricing(){
	
	//Pricing Function:
	//Current Price($1.5)+ Margin $1.5*(Location-History+GallonsReq+CompanyProfit+Season)
	//Location= .02 Texas, .04 otherwise
	//History= .01 withHistory, 0 otherwise
	//Gallon= .02 >=1000Gal, .03 <1000
	//CompanyProfit= .1 Always
	//Season= .04 Summer, .03 otherwise
	
		if(isset($_POST["newGallonRequested"])){
 		if(preg_match('/^[0-9]{1,9}$/', $_POST["newGallonRequested"])){
			
			//Get Location Factor and Delivery Address
				$item = null;
               $value = null;

              $client_info = ControllerUser::ctrShowUser($item, $value);
			if($client_info["state"]=="TX"){
				$LocationFactor=.02;
			}else{
				$LocationFactor=.04;
			}

			
			//GetRateHistory
			$item = null;
			$value = null;
			$user = ControllerHistory::ctrShowHistory($item, $value);
			  
              if ($user == False) {
				  $HistoryFactor=0;
			  }
			  else {	
					$HistoryFactor=.01;
			  }
			  
			  //GallonsFactor
			  if ($_POST["newGallonRequested"]>=1000)
			  {
				  $GallonsFactor=.02;
			  }
			  else{
				  $GallonsFactor=.03;
			  }
			  
			  //CompanyProfit
			  $CompanyProfit=.1;
			  
			  //SeasonRate
			  //Summer is between June 20th, September 22
			  $summerBegin= new DateTime('June 20');
			  $summerEnd= new DateTime('September 22');
			  $currentDate= new DateTime($_POST["newDeliveryDate"]);
			  if($currentDate>=$summerBegin && $currentDate<=$summerEnd){
				  $SeasonRate=.04;
			  }
			  else{
				  $SeasonRate=.03;
			  }
			  $SuggestedPrice=(1.5)*(1+$LocationFactor-$HistoryFactor+$GallonsFactor+$CompanyProfit+$SeasonRate);
			  return $SuggestedPrice;
	
		}else{

 			echo  '<script>
		
		swal({

				type: "error",
				title: "Information cannot be blank or contain special characters!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';
		}
		
		
		}
	
	
}

}