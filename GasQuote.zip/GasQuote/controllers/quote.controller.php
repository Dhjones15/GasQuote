<?php

class ControllerQuote{

	static public function ctrShowQuote(){
		/*
		$user = $_SESSION["username"];
		$request = ModelQuote::modShowQuote( $user);

		return $request;
		*/
		return False;
	}


static public function ctrCreateQuote(){
	
 	if(isset($_POST["newGallonRequested"])){
 		if(preg_match('/^[0-9]{1,9}$/', $_POST["newGallonRequested"])){
			/*for use later when we need to calculate price
			$client_info = ControllerUser::ctrShowUser();
			if($client_info["state"]=="TX"){
				$in_state=True;
			}else{
				$in_state=False;
			}
			$delivery_addr=$client_info["address1"];
			*/
 			$user = $_SESSION["username"];
 			$data = array(
 						 "username1" => $_SESSION["username"],	
 						"gallons_requested" => $_POST["newGallonRequested"],
						 "delivery_date" => $_POST["newDeliveryDate"],
						 "suggested_price" => ($_POST["newGallonRequested"]*1.5),
						"total_due" => $_POST["newGallonRequested"]*1.5+1
						);
 			$response = ModelQuote::mdlCreateQuote($user,$data);
 			if($response == "ok"){
 		echo  '<script>
		swal({
				type: "success",
				title: "Information is saved succesfully! ",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';

 			}else{
 		echo  '<script>
		swal({
				type: "error",
				title: "Error! Something Went Wrong",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';


 			}




 		}else{

 			echo  '<script>
		
		swal({

				type: "error",
				title: "Information cannot be blank or contain special characters!",
				showConfirmButton: true,
				confirmButtonText: "Close",
				closeOnConfirm: false

				}).then((result)=>{

					if(result.value){

						window.location="quote";
					}

					});


		</script>';
}



 	}

 }
}