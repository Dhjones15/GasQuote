<?php

class ControllerHistory{

	static public function ctrShowHistory(){
		$user = $_SESSION["username"];
		$request = ModelHistory::modShowHistory($user);
		return $request;

	}

   }