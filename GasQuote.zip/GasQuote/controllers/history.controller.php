<?php

class ControllerHistory{

	static public function ctrShowHistory($item, $value){
		$table = 'fuel_quote';
		$table1 = 'client_info';
		$user = $_SESSION["username"];
		$request = ModelHistory::modShowHistory($table, $table1, $user, $item, $value);
		return $request;
		

	}

   }