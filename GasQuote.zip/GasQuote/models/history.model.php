<?php

class ModelHistory{
	public function modShowHistory($user)
		{
			$stmt =  Connection::connector()->prepare("SELECT * FROM fuel_quote WHERE username = :$user");
			$stmt -> bindParam(":".$user, $user, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetchall();
			$stmt -> close();
		    $stmt = null;

		}
   }