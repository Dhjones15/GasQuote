<?php

class ModelHistory{
	public function modShowHistory($table, $table1, $user, $item, $value){

	if($item != null){

			$stmt =  Connection::connector()->prepare("SELECT t1.* FROM $table t1  WHERE $item = :$item");
			$stmt -> bindParam(":".$item, $value, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetch();


			}else{

				$stmt =  Connection::connector()->prepare("SELECT t1.*, t2.* FROM $table t1, $table1 t2 WHERE (t1.username = '$user' AND t1.username = t2.username)");
				//("SELECT t1.*, t2.* FROM $table t1, $table1 t2 WHERE (t1.username1 = '$user' AND t1.username1 = t2.username)")
				$stmt -> execute();

				return $stmt -> fetchall();
			}


			$stmt -> close();
		    $stmt = null;
		    

   }
}