<?php

class ModelQuote{
	public function modShowQuote($table, $table1, $user, $item, $value)
		{
/*
			if($item != null){

			$stmt =  Connection::connector()->prepare("SELECT t1.*, t2.* FROM $table t1, $table1 t2 WHERE $item = :$item");
			$stmt -> bindParam(":".$item, $value, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetch();


			}else{

				$stmt =  Connection::connector()->prepare("SELECT t1.*, t2.* FROM $table t1, $table1 t2 WHERE (t1.username1 = '$user' AND t1.username1 = t2.username) AND (t1.quote_id = (SELECT MAX(quote_id) FROM $table) )");
				//("SELECT t1.*, t2.* FROM $table t1, $table1 t2 WHERE (t1.username1 = '$user' AND t1.username1 = t2.username)")
				$stmt -> execute();

				return $stmt -> fetchall();
			}


			$stmt -> close();
		    $stmt = null;
			*/

		}
   

    public function mdlCreateQuote($user,$data)
		{

			$stmt = Connection::connector()->prepare("INSERT INTO 
		fuel_quote(gallons_requested, delivery_date, username,suggested_price,amount_due) VALUES (:gallons_requested, :delivery_date, :username1, :suggested_price, :total_due)");
		
		$stmt -> bindParam(":username1", $data["username1"], PDO::PARAM_STR);
		$stmt -> bindParam(":gallons_requested", $data["gallons_requested"], PDO::PARAM_STR);
		$stmt -> bindParam(":delivery_date", $data["delivery_date"], PDO::PARAM_STR);
		$stmt -> bindParam(":suggested_price", $data["suggested_price"], PDO::PARAM_STR);
		$stmt -> bindParam(":total_due", $data["total_due"], PDO::PARAM_STR);

		if($stmt -> execute()){
            return "ok";
		}else{
			return "error";
		}
		$stmt -> close();
		$stmt = null;

		}



}