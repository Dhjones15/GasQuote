<?php

require_once "connection.php";

class ModelUser{

	public function mdlLogin($table, $item, $value){

		$stmt = Connection::connector()->prepare("SELECT * FROM $table WHERE $item = :$item");
		$stmt -> bindParam(":".$item, $value, PDO::PARAM_STR);
		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();
		$stmt = null;
	}
	static public function mdlRegister($user, $pass){
		$stmt = Connection::connector()->prepare("INSERT INTO login (username, password) VALUES(:$user,:$pass)");
		$stmt -> bindParam(":".$user, $user, PDO::PARAM_STR);
		$stmt -> bindParam(":".$pass, $pass, PDO::PARAM_STR);
		
		if($stmt -> execute()){
            return "ok";
		}else{
			return "error";
		}
		$stmt -> close();
		$stmt = null;
		}
	public function mdlHasInfo($user)
		{

			$stmt =  Connection::connector()->prepare("SELECT * FROM client_info WHERE username = :$user");
			$stmt -> bindParam(":".$user, $user, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetch();

			$stmt -> close();
		    $stmt = null;

		}


    static public function mdlCreateUser($table, $data){
		$stmt = Connection::connector()->prepare("INSERT INTO 
		$table(client_name, address1, address2, city, state, zip, username) VALUES (:client_name, :address1, :address2, :city, :state, :zip, :username)");
		$stmt -> bindParam(":username", $data["username"], PDO::PARAM_STR);
		$stmt -> bindParam(":client_name", $data["client_name"], PDO::PARAM_STR);
		$stmt -> bindParam(":address1", $data["address1"], PDO::PARAM_STR);
		$stmt -> bindParam(":address2", $data["address2"], PDO::PARAM_STR);
		$stmt -> bindParam(":city", $data["city"], PDO::PARAM_STR);
		$stmt -> bindParam(":state", $data["state"], PDO::PARAM_STR);
		$stmt -> bindParam(":zip", $data["zip"], PDO::PARAM_STR);
		

		if($stmt -> execute()){
            return "ok";
		}else{
			return "error";
		}
		$stmt -> close();
		$stmt = null;
		}

	public function modShowUsers($user)
		{

			$stmt =  Connection::connector()->prepare("SELECT * FROM client_info WHERE username = :$user");
			$stmt -> bindParam(":".$user, $user, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetch();

			$stmt -> close();
		    $stmt = null;

		}



		/* Edit Clients */
		static public function mdlEditUser($table, $data){
		$stmt = Connection::connector()->prepare("UPDATE $table SET username = :username, client_name = :client_name, address1=:address1, address2 = :address2, city=:city, state = :state, zip = :zip WHERE username = :username");
		$stmt -> bindParam(":username", $data["username"], PDO::PARAM_STR);
		$stmt -> bindParam(":client_name", $data["client_name"], PDO::PARAM_STR);
		$stmt -> bindParam(":address1", $data["address1"], PDO::PARAM_STR);
		$stmt -> bindParam(":address2", $data["address2"], PDO::PARAM_STR);
		$stmt -> bindParam(":city", $data["city"], PDO::PARAM_STR);
		$stmt -> bindParam(":state", $data["state"], PDO::PARAM_STR);
		$stmt -> bindParam(":zip", $data["zip"], PDO::PARAM_STR);
		if($stmt -> execute()){
          return "ok";
		}else{
		   return "error";
		}
		$stmt -> close();
		$stmt = null;
		}




}
