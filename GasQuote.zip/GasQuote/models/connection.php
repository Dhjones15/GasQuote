<?php

class Connection{
	public function connector(){

		$link = new PDO("mysql:host=localhost;dbname=gasquote","root","");

		$link->exec("set names utf8");

		return $link; 
	}
}