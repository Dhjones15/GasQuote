<?php
require_once "controllers/template.controller.php";
require_once "controllers/profile.controller.php";
require_once "controllers/history.controller.php";
require_once "controllers/quote.controller.php";


require_once "models/profile.model.php";
require_once "models/history.model.php";
require_once "models/quote.model.php";

$template = new ControllerTemplate();
$template -> ctrTemplate();
